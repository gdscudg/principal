fac :: Integer ->Integer
fac 0 = 1 --Rekursionsanker
fac n
  | n>0 = n * fac (n-1)
  | otherwise = error "Die Eingabe muss eine natürliche Zahle sein."